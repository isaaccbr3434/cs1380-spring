
function put(state, configuration, callback) {
};

function get(configuration, callback) {
}

function del(configuration, callback) {
};

module.exports = {put, get, del};
