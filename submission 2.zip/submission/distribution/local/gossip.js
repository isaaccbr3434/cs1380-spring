const gossip = {};


gossip.recv = function(payload, callback) {
};

module.exports = gossip;
